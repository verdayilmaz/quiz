﻿namespace Quiz1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBoxMusteriBilgileri = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtAdSoyad = new System.Windows.Forms.TextBox();
            this.txtTelefon = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.groupBoxUrunler = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbKahveler = new System.Windows.Forms.ComboBox();
            this.numericUpDownKahveler = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.numericUpDownSogukIcecekler = new System.Windows.Forms.NumericUpDown();
            this.cmbSicakIcecekler = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.groupBoxExtralar = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cbShot1x = new System.Windows.Forms.CheckBox();
            this.cbShot2x = new System.Windows.Forms.CheckBox();
            this.btnHesapla = new System.Windows.Forms.Button();
            this.groupBoxSiparisler = new System.Windows.Forms.GroupBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label11 = new System.Windows.Forms.Label();
            this.lblToplamSiparisTutari = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.btnSiparisVer = new System.Windows.Forms.Button();
            this.numericUpDownSicakIcecekler = new System.Windows.Forms.NumericUpDown();
            this.cmbSogukIcecekler = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.groupBoxSut = new System.Windows.Forms.GroupBox();
            this.rbSutSoya = new System.Windows.Forms.RadioButton();
            this.rbSutYagsiz = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBoxIcecekBoyutu = new System.Windows.Forms.GroupBox();
            this.rbBoyutTall = new System.Windows.Forms.RadioButton();
            this.rbBoyutGrande = new System.Windows.Forms.RadioButton();
            this.rbBoyutVenti = new System.Windows.Forms.RadioButton();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBoxMusteriBilgileri.SuspendLayout();
            this.groupBoxUrunler.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownKahveler)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSogukIcecekler)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBoxExtralar.SuspendLayout();
            this.groupBoxSiparisler.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSicakIcecekler)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.groupBoxSut.SuspendLayout();
            this.groupBoxIcecekBoyutu.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxMusteriBilgileri
            // 
            this.groupBoxMusteriBilgileri.Controls.Add(this.txtAddress);
            this.groupBoxMusteriBilgileri.Controls.Add(this.txtTelefon);
            this.groupBoxMusteriBilgileri.Controls.Add(this.txtAdSoyad);
            this.groupBoxMusteriBilgileri.Controls.Add(this.label3);
            this.groupBoxMusteriBilgileri.Controls.Add(this.label2);
            this.groupBoxMusteriBilgileri.Controls.Add(this.label1);
            this.groupBoxMusteriBilgileri.Location = new System.Drawing.Point(25, 28);
            this.groupBoxMusteriBilgileri.Name = "groupBoxMusteriBilgileri";
            this.groupBoxMusteriBilgileri.Size = new System.Drawing.Size(351, 128);
            this.groupBoxMusteriBilgileri.TabIndex = 0;
            this.groupBoxMusteriBilgileri.TabStop = false;
            this.groupBoxMusteriBilgileri.Text = "Müşteri Bilgileri";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(20, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ad Soyad:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(20, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Telefon:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(20, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Adres:";
            // 
            // txtAdSoyad
            // 
            this.txtAdSoyad.Location = new System.Drawing.Point(96, 15);
            this.txtAdSoyad.Name = "txtAdSoyad";
            this.txtAdSoyad.Size = new System.Drawing.Size(249, 20);
            this.txtAdSoyad.TabIndex = 3;
            // 
            // txtTelefon
            // 
            this.txtTelefon.Location = new System.Drawing.Point(96, 44);
            this.txtTelefon.Name = "txtTelefon";
            this.txtTelefon.Size = new System.Drawing.Size(249, 20);
            this.txtTelefon.TabIndex = 4;
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(96, 72);
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(249, 50);
            this.txtAddress.TabIndex = 5;
            // 
            // groupBoxUrunler
            // 
            this.groupBoxUrunler.Controls.Add(this.numericUpDownSicakIcecekler);
            this.groupBoxUrunler.Controls.Add(this.cmbSogukIcecekler);
            this.groupBoxUrunler.Controls.Add(this.label7);
            this.groupBoxUrunler.Controls.Add(this.pictureBox3);
            this.groupBoxUrunler.Controls.Add(this.btnHesapla);
            this.groupBoxUrunler.Controls.Add(this.groupBoxExtralar);
            this.groupBoxUrunler.Controls.Add(this.numericUpDownSogukIcecekler);
            this.groupBoxUrunler.Controls.Add(this.cmbSicakIcecekler);
            this.groupBoxUrunler.Controls.Add(this.label6);
            this.groupBoxUrunler.Controls.Add(this.pictureBox2);
            this.groupBoxUrunler.Controls.Add(this.label5);
            this.groupBoxUrunler.Controls.Add(this.numericUpDownKahveler);
            this.groupBoxUrunler.Controls.Add(this.cmbKahveler);
            this.groupBoxUrunler.Controls.Add(this.label4);
            this.groupBoxUrunler.Controls.Add(this.pictureBox1);
            this.groupBoxUrunler.Location = new System.Drawing.Point(25, 162);
            this.groupBoxUrunler.Name = "groupBoxUrunler";
            this.groupBoxUrunler.Size = new System.Drawing.Size(351, 313);
            this.groupBoxUrunler.TabIndex = 1;
            this.groupBoxUrunler.TabStop = false;
            this.groupBoxUrunler.Text = "Ürünler";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(11, 34);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(29, 32);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(48, 43);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Kahveler:";
            // 
            // cmbKahveler
            // 
            this.cmbKahveler.FormattingEnabled = true;
            this.cmbKahveler.Location = new System.Drawing.Point(135, 40);
            this.cmbKahveler.Name = "cmbKahveler";
            this.cmbKahveler.Size = new System.Drawing.Size(155, 21);
            this.cmbKahveler.TabIndex = 2;
            // 
            // numericUpDownKahveler
            // 
            this.numericUpDownKahveler.Location = new System.Drawing.Point(296, 41);
            this.numericUpDownKahveler.Name = "numericUpDownKahveler";
            this.numericUpDownKahveler.Size = new System.Drawing.Size(43, 20);
            this.numericUpDownKahveler.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(306, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Adet";
            // 
            // numericUpDownSogukIcecekler
            // 
            this.numericUpDownSogukIcecekler.Location = new System.Drawing.Point(296, 123);
            this.numericUpDownSogukIcecekler.Name = "numericUpDownSogukIcecekler";
            this.numericUpDownSogukIcecekler.Size = new System.Drawing.Size(43, 20);
            this.numericUpDownSogukIcecekler.TabIndex = 8;
            // 
            // cmbSicakIcecekler
            // 
            this.cmbSicakIcecekler.FormattingEnabled = true;
            this.cmbSicakIcecekler.Location = new System.Drawing.Point(135, 122);
            this.cmbSicakIcecekler.Name = "cmbSicakIcecekler";
            this.cmbSicakIcecekler.Size = new System.Drawing.Size(155, 21);
            this.cmbSicakIcecekler.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(48, 125);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "Sıcak İçecekler:";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(11, 116);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(29, 32);
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            // 
            // groupBoxExtralar
            // 
            this.groupBoxExtralar.Controls.Add(this.groupBoxIcecekBoyutu);
            this.groupBoxExtralar.Controls.Add(this.groupBoxSut);
            this.groupBoxExtralar.Controls.Add(this.cbShot2x);
            this.groupBoxExtralar.Controls.Add(this.cbShot1x);
            this.groupBoxExtralar.Controls.Add(this.label8);
            this.groupBoxExtralar.Location = new System.Drawing.Point(23, 150);
            this.groupBoxExtralar.Name = "groupBoxExtralar";
            this.groupBoxExtralar.Size = new System.Drawing.Size(312, 114);
            this.groupBoxExtralar.TabIndex = 13;
            this.groupBoxExtralar.TabStop = false;
            this.groupBoxExtralar.Text = "Extralar";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(13, 27);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(32, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "Shot:";
            // 
            // cbShot1x
            // 
            this.cbShot1x.AutoSize = true;
            this.cbShot1x.Location = new System.Drawing.Point(103, 23);
            this.cbShot1x.Name = "cbShot1x";
            this.cbShot1x.Size = new System.Drawing.Size(37, 17);
            this.cbShot1x.TabIndex = 2;
            this.cbShot1x.Text = "1x";
            this.cbShot1x.UseVisualStyleBackColor = true;
            // 
            // cbShot2x
            // 
            this.cbShot2x.AutoSize = true;
            this.cbShot2x.Location = new System.Drawing.Point(146, 23);
            this.cbShot2x.Name = "cbShot2x";
            this.cbShot2x.Size = new System.Drawing.Size(37, 17);
            this.cbShot2x.TabIndex = 3;
            this.cbShot2x.Text = "2x";
            this.cbShot2x.UseVisualStyleBackColor = true;
            // 
            // btnHesapla
            // 
            this.btnHesapla.Location = new System.Drawing.Point(39, 270);
            this.btnHesapla.Name = "btnHesapla";
            this.btnHesapla.Size = new System.Drawing.Size(291, 34);
            this.btnHesapla.TabIndex = 14;
            this.btnHesapla.Text = "Hesapla";
            this.btnHesapla.UseVisualStyleBackColor = true;
            this.btnHesapla.Click += new System.EventHandler(this.btnHesapla_Click);
            // 
            // groupBoxSiparisler
            // 
            this.groupBoxSiparisler.Controls.Add(this.btnSiparisVer);
            this.groupBoxSiparisler.Controls.Add(this.label12);
            this.groupBoxSiparisler.Controls.Add(this.lblToplamSiparisTutari);
            this.groupBoxSiparisler.Controls.Add(this.label11);
            this.groupBoxSiparisler.Controls.Add(this.listBox1);
            this.groupBoxSiparisler.Location = new System.Drawing.Point(382, 28);
            this.groupBoxSiparisler.Name = "groupBoxSiparisler";
            this.groupBoxSiparisler.Size = new System.Drawing.Size(325, 447);
            this.groupBoxSiparisler.TabIndex = 2;
            this.groupBoxSiparisler.TabStop = false;
            this.groupBoxSiparisler.Text = "Siparişler";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(6, 20);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(319, 342);
            this.listBox1.TabIndex = 0;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.Location = new System.Drawing.Point(8, 379);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(162, 16);
            this.label11.TabIndex = 1;
            this.label11.Text = "Toplam Sipariş Tutarı:";
            // 
            // lblToplamSiparisTutari
            // 
            this.lblToplamSiparisTutari.AutoSize = true;
            this.lblToplamSiparisTutari.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblToplamSiparisTutari.Location = new System.Drawing.Point(195, 382);
            this.lblToplamSiparisTutari.Name = "lblToplamSiparisTutari";
            this.lblToplamSiparisTutari.Size = new System.Drawing.Size(53, 16);
            this.lblToplamSiparisTutari.TabIndex = 2;
            this.lblToplamSiparisTutari.Text = "- - - - - ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.Location = new System.Drawing.Point(278, 381);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(30, 16);
            this.label12.TabIndex = 3;
            this.label12.Text = "TL.";
            // 
            // btnSiparisVer
            // 
            this.btnSiparisVer.Location = new System.Drawing.Point(6, 404);
            this.btnSiparisVer.Name = "btnSiparisVer";
            this.btnSiparisVer.Size = new System.Drawing.Size(291, 34);
            this.btnSiparisVer.TabIndex = 15;
            this.btnSiparisVer.Text = "Sipariş Ver";
            this.btnSiparisVer.UseVisualStyleBackColor = true;
            // 
            // numericUpDownSicakIcecekler
            // 
            this.numericUpDownSicakIcecekler.Location = new System.Drawing.Point(296, 83);
            this.numericUpDownSicakIcecekler.Name = "numericUpDownSicakIcecekler";
            this.numericUpDownSicakIcecekler.Size = new System.Drawing.Size(43, 20);
            this.numericUpDownSicakIcecekler.TabIndex = 18;
            // 
            // cmbSogukIcecekler
            // 
            this.cmbSogukIcecekler.FormattingEnabled = true;
            this.cmbSogukIcecekler.Location = new System.Drawing.Point(135, 82);
            this.cmbSogukIcecekler.Name = "cmbSogukIcecekler";
            this.cmbSogukIcecekler.Size = new System.Drawing.Size(155, 21);
            this.cmbSogukIcecekler.TabIndex = 17;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(48, 85);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(88, 13);
            this.label7.TabIndex = 16;
            this.label7.Text = "Soğuk İçecekler:";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(11, 76);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(29, 32);
            this.pictureBox3.TabIndex = 15;
            this.pictureBox3.TabStop = false;
            // 
            // groupBoxSut
            // 
            this.groupBoxSut.Controls.Add(this.rbSutSoya);
            this.groupBoxSut.Controls.Add(this.rbSutYagsiz);
            this.groupBoxSut.Controls.Add(this.label9);
            this.groupBoxSut.Location = new System.Drawing.Point(16, 43);
            this.groupBoxSut.Name = "groupBoxSut";
            this.groupBoxSut.Size = new System.Drawing.Size(290, 30);
            this.groupBoxSut.TabIndex = 10;
            this.groupBoxSut.TabStop = false;
            // 
            // rbSutSoya
            // 
            this.rbSutSoya.AutoSize = true;
            this.rbSutSoya.Location = new System.Drawing.Point(152, 6);
            this.rbSutSoya.Name = "rbSutSoya";
            this.rbSutSoya.Size = new System.Drawing.Size(49, 17);
            this.rbSutSoya.TabIndex = 8;
            this.rbSutSoya.TabStop = true;
            this.rbSutSoya.Text = "Soya";
            this.rbSutSoya.UseVisualStyleBackColor = true;
            // 
            // rbSutYagsiz
            // 
            this.rbSutYagsiz.AutoSize = true;
            this.rbSutYagsiz.Location = new System.Drawing.Point(88, 6);
            this.rbSutYagsiz.Name = "rbSutYagsiz";
            this.rbSutYagsiz.Size = new System.Drawing.Size(56, 17);
            this.rbSutYagsiz.TabIndex = 7;
            this.rbSutYagsiz.TabStop = true;
            this.rbSutYagsiz.Text = "Yağsız";
            this.rbSutYagsiz.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1, 11);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(26, 13);
            this.label9.TabIndex = 6;
            this.label9.Text = "Süt:";
            // 
            // groupBoxIcecekBoyutu
            // 
            this.groupBoxIcecekBoyutu.Controls.Add(this.rbBoyutTall);
            this.groupBoxIcecekBoyutu.Controls.Add(this.rbBoyutGrande);
            this.groupBoxIcecekBoyutu.Controls.Add(this.rbBoyutVenti);
            this.groupBoxIcecekBoyutu.Controls.Add(this.label10);
            this.groupBoxIcecekBoyutu.Location = new System.Drawing.Point(16, 79);
            this.groupBoxIcecekBoyutu.Name = "groupBoxIcecekBoyutu";
            this.groupBoxIcecekBoyutu.Size = new System.Drawing.Size(290, 28);
            this.groupBoxIcecekBoyutu.TabIndex = 11;
            this.groupBoxIcecekBoyutu.TabStop = false;
            // 
            // rbBoyutTall
            // 
            this.rbBoyutTall.AutoSize = true;
            this.rbBoyutTall.Location = new System.Drawing.Point(210, 11);
            this.rbBoyutTall.Name = "rbBoyutTall";
            this.rbBoyutTall.Size = new System.Drawing.Size(42, 17);
            this.rbBoyutTall.TabIndex = 13;
            this.rbBoyutTall.TabStop = true;
            this.rbBoyutTall.Text = "Tall";
            this.rbBoyutTall.UseVisualStyleBackColor = true;
            // 
            // rbBoyutGrande
            // 
            this.rbBoyutGrande.AutoSize = true;
            this.rbBoyutGrande.Location = new System.Drawing.Point(144, 11);
            this.rbBoyutGrande.Name = "rbBoyutGrande";
            this.rbBoyutGrande.Size = new System.Drawing.Size(60, 17);
            this.rbBoyutGrande.TabIndex = 12;
            this.rbBoyutGrande.TabStop = true;
            this.rbBoyutGrande.Text = "Grande";
            this.rbBoyutGrande.UseVisualStyleBackColor = true;
            // 
            // rbBoyutVenti
            // 
            this.rbBoyutVenti.AutoSize = true;
            this.rbBoyutVenti.Location = new System.Drawing.Point(89, 11);
            this.rbBoyutVenti.Name = "rbBoyutVenti";
            this.rbBoyutVenti.Size = new System.Drawing.Size(49, 17);
            this.rbBoyutVenti.TabIndex = 11;
            this.rbBoyutVenti.TabStop = true;
            this.rbBoyutVenti.Text = "Venti";
            this.rbBoyutVenti.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(3, 11);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(79, 13);
            this.label10.TabIndex = 10;
            this.label10.Text = "İçecek Boyutu:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(711, 487);
            this.Controls.Add(this.groupBoxSiparisler);
            this.Controls.Add(this.groupBoxUrunler);
            this.Controls.Add(this.groupBoxMusteriBilgileri);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBoxMusteriBilgileri.ResumeLayout(false);
            this.groupBoxMusteriBilgileri.PerformLayout();
            this.groupBoxUrunler.ResumeLayout(false);
            this.groupBoxUrunler.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownKahveler)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSogukIcecekler)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBoxExtralar.ResumeLayout(false);
            this.groupBoxExtralar.PerformLayout();
            this.groupBoxSiparisler.ResumeLayout(false);
            this.groupBoxSiparisler.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSicakIcecekler)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.groupBoxSut.ResumeLayout(false);
            this.groupBoxSut.PerformLayout();
            this.groupBoxIcecekBoyutu.ResumeLayout(false);
            this.groupBoxIcecekBoyutu.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxMusteriBilgileri;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtTelefon;
        private System.Windows.Forms.TextBox txtAdSoyad;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBoxUrunler;
        private System.Windows.Forms.NumericUpDown numericUpDownSogukIcecekler;
        private System.Windows.Forms.ComboBox cmbSicakIcecekler;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown numericUpDownKahveler;
        private System.Windows.Forms.ComboBox cmbKahveler;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBoxExtralar;
        private System.Windows.Forms.CheckBox cbShot2x;
        private System.Windows.Forms.CheckBox cbShot1x;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnHesapla;
        private System.Windows.Forms.GroupBox groupBoxSiparisler;
        private System.Windows.Forms.Button btnSiparisVer;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblToplamSiparisTutari;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.NumericUpDown numericUpDownSicakIcecekler;
        private System.Windows.Forms.ComboBox cmbSogukIcecekler;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.GroupBox groupBoxSut;
        private System.Windows.Forms.RadioButton rbSutSoya;
        private System.Windows.Forms.RadioButton rbSutYagsiz;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBoxIcecekBoyutu;
        private System.Windows.Forms.RadioButton rbBoyutTall;
        private System.Windows.Forms.RadioButton rbBoyutGrande;
        private System.Windows.Forms.RadioButton rbBoyutVenti;
        private System.Windows.Forms.Label label10;
    }
}

