﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quiz1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            #region ComboBoxKahveler Doldur
            cmbKahveler.Items.Add("Misto");
            cmbKahveler.Items.Add("Americano");
            cmbKahveler.Items.Add("Cappucino");
            cmbKahveler.Items.Add("Macchiato");
            cmbKahveler.Items.Add("Con Panna");
            cmbKahveler.Items.Add("Mocha");
            #endregion

            #region ComboBoxSogukIcecekler Doldur
            cmbSogukIcecekler.Items.Add("Soğuk Çay");
            cmbSogukIcecekler.Items.Add("Limonata");
            #endregion

            #region ComboBoxSicakIcecekler Doldur
            cmbSicakIcecekler.Items.Add("Çay");
            cmbSicakIcecekler.Items.Add("Hot Chocolate");
            cmbSicakIcecekler.Items.Add("Chai Tea Latte");
            #endregion
        }

        ArrayList arList = new ArrayList();
        ArrayList arListSon = new ArrayList();
        double birimFiyat = 0;
        double tutar = 0;
        string listValue;

        private void btnHesapla_Click(object sender, EventArgs e)
        {
            listValue = "";
            if (cmbKahveler.Text != "")
            {
                /*"Misto=4,5 TL", "Americano=5,75 TL”, "Bianco= 6 TL ”,
                    ”Cappucino = 7,5 TL”, ”Macchiato = 6,75 TL ”,
                    ”Con Panna = 8 TL”, ”Mocha=7,75TL”*/
                if (cmbKahveler.Text == "Misto")
                {
                    birimFiyat = 4.5;
                    // arList.Add("Misto");
                    listValue = "Misto";

                }
                else if (cmbKahveler.Text == "Americano")
                {
                    birimFiyat = 5.75;
                   // arList.Add("Americano");
                    listValue = "Americano";
                }
                else if (cmbKahveler.Text == "Bianco")
                {
                    birimFiyat = 6;
                    //arList.Add("Bianco");
                    listValue = "Bianco";
                }
                else if (cmbKahveler.Text == "Cappucino")
                {
                    birimFiyat = 7.5;
                   // arList.Add("Cappucino");
                    listValue = "Cappucino";
                }
                else if (cmbKahveler.Text == "Macchiato")
                {
                    birimFiyat = 6.75;
                    //arList.Add("Macchiato");
                    listValue = "Macchiato";
                }
                else if (cmbKahveler.Text == "Con Panna")
                {
                    birimFiyat = 8;
                    //arList.Add("Con Panna");
                    listValue = "Con Panna";
                }
                else if (cmbKahveler.Text == "Mocha")
                {
                    birimFiyat = 7.75;
                   // arList.Add("Mocha");
                    listValue = "Mocha";
                }
                else
                {
                    arList.Add("---");
                }

            }

            //soğuk icecekler hesaplama
            if (cmbSogukIcecekler.Text != "")
            {
                /*"Soğuk Çay=4,5 TL", "Limonata=5,75 TL”*/
                if (cmbKahveler.Text == "Soğuk Çay")
                {
                    birimFiyat = 4.5;
                   // arList.Add("Soğuk Çay");
                    listValue = "Soğuk Çay";
                }
                else if (cmbKahveler.Text == "Limonata")
                {
                    birimFiyat = 5.75;
                    //arList.Add("Limonata");
                    listValue = "Limonata";
                }
                else
                {
                    arList.Add("---");
                }
            }

            //sicak icecekler hesaplama
            if (cmbSicakIcecekler.Text != "")
            {
                /*“Çay = 3 TL”, “Hot Chocolate = 4,5 TL”, “Chai Tea Latte = 6,5 TL”*/
                if (cmbKahveler.Text == "Çay")
                {
                    birimFiyat = 3;
                    //arList.Add("Çay");
                    listValue = "Çay";
                }
                else if (cmbKahveler.Text == "Hot Chocolate")
                {
                    birimFiyat = 4.5;
                    //arList.Add("Hot Chocolate");
                    listValue = "Hot Chocolate";
                }
                else if (cmbKahveler.Text == "Chai Tea Latte")
                {
                    birimFiyat = 6.5;
                    //arList.Add("Chai Tea Latte");
                    listValue = "Chai Tea Latte";
                }
                else
                {
                    //arList.Add("---");
                    listValue = "---";
                }
            }
            //MessageBox.Show(birimFiyat.ToString());
           // MessageBox.Show("1" + arList[0].ToString());
   

            //checkbox hesaplama
            /*Shot : Eklenen her bir ölçü için 0.75 TL ek fiyat artışı olmalı.*/
            if (cbShot1x.Checked == true)
            {
                birimFiyat += 0.75;
                // arList.Add("x1 Shot");
                listValue = listValue + "#" +"x1 Shot";
            }
            else if (cbShot2x.Checked == true)
            {
                birimFiyat += 0.75;
                //arList.Add("x2 Shot");
                listValue = listValue + "#" + "x2 Shot";
            }
            else
            {
                //arList.Add("---");
                listValue = listValue + "#" + "---";
            }

            //Radio Button Hesaplama
            /*Süt : Eklenen her bir ölçü için 0.5 TL ek fiyat artışı olmalı.
            Kahve Boyutu Katsayıları : “Tall =1”, “Grande=1,25”, “Venti = 1,75”*/
            if (rbSutYagsiz.Checked == true)
            {
                birimFiyat += 0.5;
                //arList.Add("Yağsız Süt");
                listValue = listValue + "#" + "Yağsız Süt";
            } 
            else if (rbSutSoya.Checked == true)
            {
                birimFiyat += 0.5;
                // arList.Add("Soya");
                listValue = listValue + "#" + "Soya";
            }
            else
            {
                // arList.Add("---");
                listValue = listValue + "#" + "---";
            }

            if (rbBoyutVenti.Checked == true)
            {
                birimFiyat += 1.75;
                //arList.Add("Venti");
                listValue = listValue + "#" + "Venti";
            }
            else if (rbBoyutGrande.Checked == true)
            {
                birimFiyat += 1.25;
                //arList.Add("Grande");
                listValue = listValue + "#" + "Grande";
            }
            else if (rbBoyutTall.Checked == true)
            {
                birimFiyat += 1.0;
                //arList.Add("Tall");
                listValue = listValue + "#" + "Tall";
            }
            else
            {
                // arList.Add("---");
                listValue = listValue + "#" + "---";
            }
            /*
            arList.Add(birimFiyat.ToString());

            foreach (string item in arList)
            {
                MessageBox.Show(item);
            }


            arListSon.Add(arList[3] + ", " + arList[0] + ',' + arList[1] + ',' + arList[4]);

            foreach (string item in arListSon)
            {
                listBox1.Items.Add(item);
            }
            

            tutar += Convert.ToDouble(arList[4]);
            lblToplamSiparisTutari.Text = tutar.ToString();
            */
            string[] colAr = listValue.Split('#');
            listBox1.Items.Add(colAr[3] + ", " + colAr[0] + ',' + colAr[1] + ',' );
        }
    }
}
